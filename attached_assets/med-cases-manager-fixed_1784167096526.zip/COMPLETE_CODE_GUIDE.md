# 📚 دليل الكود البرمجي الكامل - نظام إدارة الحالات الطبية BSCH

**إصدار:** 2.0  
**التاريخ:** 10 يوليو 2026  
**الحالة:** ✅ جاهز للاستخدام

---

## 📋 جدول المحتويات

1. [نظرة عامة](#نظرة-عامة)
2. [الميزات المضافة](#الميزات-المضافة)
3. [الملفات الرئيسية](#الملفات-الرئيسية)
4. [شرح الكود](#شرح-الكود)
5. [التعديلات المتبقية](#التعديلات-المتبقية)
6. [كيفية الاستكمال](#كيفية-الاستكمال)

---

## 🎯 نظرة عامة

نظام BSCH هو منصة ويب متكاملة لإدارة حالات المرضى في غرف الحضانة الطبية. تم تطويره باستخدام:

- **Frontend:** React 19 + Tailwind CSS 4 + TypeScript
- **Backend:** Express 4 + tRPC 11 + Node.js
- **Database:** MySQL / TiDB
- **AI:** LLM API لتحليل البيانات

---

## ✨ الميزات المضافة

### 1. ✅ صفحة إضافة حالة مبسطة (AddCase.tsx)
- **المسار:** `/add-case`
- **الميزات:**
  - إدخال اسم الحالة والمكان فقط (مطلوب)
  - بيانات إضافية اختيارية قابلة للتوسع
  - ملخص البيانات قبل الإدخال
  - تأكيد البيانات عبر checklist
  - إشعارات واضحة عند النجاح/الفشل

### 2. ✅ الإدخال الجماعي مع AI (BulkImport.tsx)
- **المسار:** `/bulk-import`
- **الميزات:**
  - تحليل ذكي للبيانات باستخدام LLM
  - اختيار القسم/المكان قبل الإدخال
  - خطوة تعديل البيانات المستخرجة
  - عرض ملخص البيانات قبل الاستيراد
  - معالجة متقدمة للأخطاء

### 3. ✅ صفحة طباعة التقارير (PrintReports.tsx)
- **المسار:** `/print-reports`
- **الميزات:**
  - اختيار قسم واحد أو أكثر
  - ثلاث أنواع من التقارير: مختصر، تفصيلي، إحصائيات
  - طباعة مباشرة من المتصفح
  - تحميل البيانات كـ CSV
  - إحصائيات فورية للحالات المختارة

### 4. ✅ تسجيل دخول المؤسس (FounderLogin.tsx)
- **المسار:** `/founder-login`
- **الميزات:**
  - تسجيل دخول آمن بكلمة مرور
  - وصول خاص للمؤسس
  - إدارة النظام والإعدادات

---

## 📂 الملفات الرئيسية

### Frontend Pages

```
client/src/pages/
├── Home.tsx                    # الصفحة الرئيسية
├── Dashboard.tsx               # لوحة التحكم
├── AddCase.tsx                 # إضافة حالة جديدة ✅ محدث
├── BulkImport.tsx              # الإدخال الجماعي ✅ محدث
├── PrintReports.tsx            # طباعة التقارير ✅ جديد
├── DepartmentDetail.tsx        # تفاصيل القسم
├── Search.tsx                  # البحث المتقدم
├── WaitingCases.tsx            # حالات الانتظار
├── ArtificialRespiration.tsx   # حالات التنفس الصناعي
├── FounderLogin.tsx            # تسجيل دخول المؤسس ✅ جديد
└── NotFound.tsx                # صفحة 404
```

### Backend

```
server/
├── routers.ts                  # إجراءات tRPC ✅ محدث
├── db.ts                       # دوال قاعدة البيانات
├── storage.ts                  # إدارة التخزين
└── _core/
    ├── index.ts                # نقطة دخول الخادم
    ├── context.ts              # سياق tRPC
    ├── trpc.ts                 # إعدادات tRPC
    ├── llm.ts                  # تكامل LLM
    ├── oauth.ts                # OAuth
    ├── env.ts                  # متغيرات البيئة
    └── ...                     # ملفات أخرى
```

---

## 🔍 شرح الكود

### 1. صفحة إضافة حالة جديدة (AddCase.tsx)

**الهيكل الأساسي:**
```typescript
export default function AddCase() {
  const [formData, setFormData] = useState({
    patientName: "",
    departmentId: 0,
    // بيانات إضافية اختيارية
    diagnosis: "",
    symptoms: "",
    // ... إلخ
  });

  const handleSubmit = async () => {
    // التحقق من البيانات المطلوبة
    if (!formData.patientName || !formData.departmentId) {
      toast.error("❌ يرجى إدخال اسم الحالة والمكان");
      return;
    }

    // إرسال البيانات إلى الخادم
    await createCaseMutation.mutateAsync(formData);
  };
}
```

**الميزات الرئيسية:**
- ✅ تبسيط النموذج: حقول مطلوبة فقط
- ✅ بيانات إضافية قابلة للتوسع
- ✅ ملخص البيانات قبل الإدخال
- ✅ تأكيد البيانات عبر checklist
- ✅ إشعارات واضحة

### 2. الإدخال الجماعي مع AI (BulkImport.tsx)

**الخطوات الرئيسية:**
```typescript
// 1. الإدخال: لصق البيانات
const [bulkData, setBulkData] = useState("");

// 2. التحليل: استخدام AI
const analyzeMutation = trpc.ai.analyzeBulkData.useMutation();

const handleAnalyze = async () => {
  const result = await analyzeMutation.mutateAsync({
    data: bulkData,
    departmentId: selectedDepartment,
    useAI: useAIAnalysis,
  });
  
  // عرض النتائج للتعديل
  setAnalyzedCases(result);
};

// 3. التعديل: تعديل البيانات
const [editingCase, setEditingCase] = useState(null);

// 4. الاستيراد: حفظ البيانات
const importMutation = trpc.cases.create.useMutation();
```

**الميزات الرئيسية:**
- ✅ تحليل ذكي للبيانات
- ✅ اختيار القسم قبل الإدخال
- ✅ خطوة تعديل منفصلة
- ✅ معالجة الأخطاء المتقدمة
- ✅ إشعارات تفصيلية

### 3. صفحة طباعة التقارير (PrintReports.tsx)

**الخطوات الرئيسية:**
```typescript
// 1. اختيار الأقسام
const [selectedDepartments, setSelectedDepartments] = useState<number[]>([]);

// 2. اختيار نوع التقرير
const [reportType, setReportType] = useState<"summary" | "detailed" | "statistics">("summary");

// 3. فلترة البيانات
const getFilteredCases = () => {
  return allCases.filter((c) => selectedDepartments.includes(c.departmentId));
};

// 4. الطباعة
const handlePrint = () => {
  const printWindow = window.open("", "", "width=900,height=700");
  const htmlContent = generatePrintHTML(filteredCases, reportType);
  printWindow.document.write(htmlContent);
  printWindow.print();
};

// 5. التحميل
const handleDownloadPDF = () => {
  // إنشاء ملف CSV
  // تحميل الملف
};
```

**الميزات الرئيسية:**
- ✅ اختيار متعدد للأقسام
- ✅ ثلاث أنواع من التقارير
- ✅ طباعة مباشرة
- ✅ تحميل كـ CSV
- ✅ إحصائيات فورية

### 4. Backend - إجراء تحليل البيانات بـ AI

**في server/routers.ts:**
```typescript
ai: router({
  analyzeBulkData: publicProcedure
    .input(
      z.object({
        data: z.string(),
        departmentId: z.number(),
        useAI: z.boolean(),
      })
    )
    .mutation(async ({ input }) => {
      if (input.useAI) {
        // استخدام LLM لتحليل البيانات
        const response = await invokeLLM({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "user",
              content: `تحليل البيانات الطبية التالية واستخراج المعلومات:
              ${input.data}
              
              أرجع JSON بالصيغة:
              {
                "cases": [
                  {
                    "patientName": "اسم المريض",
                    "age": "السن",
                    "diagnosis": "التشخيص",
                    "symptoms": "الأعراض",
                    "phone": "الهاتف",
                    "nationalId": "الرقم القومي"
                  }
                ]
              }`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "medical_cases",
              schema: {
                type: "object",
                properties: {
                  cases: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        patientName: { type: "string" },
                        age: { type: "string" },
                        diagnosis: { type: "string" },
                        symptoms: { type: "string" },
                        phone: { type: "string" },
                        nationalId: { type: "string" },
                      },
                    },
                  },
                },
              },
            },
          },
        });

        return JSON.parse(response);
      } else {
        // تحليل بسيط: تقسيم النصوص
        const lines = input.data.split("\n");
        const cases = lines.map((line) => ({
          patientName: line.split(",")[0]?.trim() || "",
          diagnosis: line.split(",")[1]?.trim() || "",
        }));
        return { cases };
      }
    }),
}),
```

---

## 📝 التعديلات المتبقية

### 1. ❌ إضافة زر طباعة التقارير في Dashboard
**الملف:** `client/src/pages/Dashboard.tsx`
**المطلوب:**
```typescript
<Button
  onClick={() => setLocation("/print-reports")}
  className="bg-red-600 hover:bg-red-700"
>
  🖨️ طباعة التقارير
</Button>
```

### 2. ❌ ربط صفحة PrintReports في الأزرار السريعة
**الملف:** `client/src/pages/Home.tsx`
**المطلوب:**
- إضافة زر "طباعة التقارير" في الأزرار السريعة

### 3. ❌ اختبار صفحة PrintReports
**المطلوب:**
- اختبار اختيار الأقسام
- اختبار الطباعة
- اختبار التحميل كـ CSV

### 4. ❌ تحسين معالجة الأخطاء
**المطلوب:**
- إضافة رسائل خطأ أكثر تفصيلاً
- إضافة اقتراحات للتصحيح

### 5. ❌ إضافة اختبارات (Tests)
**المطلوب:**
- اختبارات للإدخال الفردي
- اختبارات للإدخال الجماعي
- اختبارات للطباعة

---

## 🚀 كيفية الاستكمال

### الخطوة 1: إضافة زر الطباعة في Dashboard

**ملف:** `client/src/pages/Dashboard.tsx`

ابحث عن قسم "الأزرار السريعة" وأضف:

```typescript
<Button
  onClick={() => setLocation("/print-reports")}
  className="w-full bg-red-600 hover:bg-red-700 text-white text-lg py-6 flex items-center justify-center gap-2"
>
  <Printer className="w-5 h-5" />
  🖨️ طباعة التقارير
</Button>
```

### الخطوة 2: اختبار صفحة PrintReports

1. اذهب إلى `/print-reports`
2. اختر قسم واحد أو أكثر
3. اختر نوع التقرير
4. اضغط "طباعة التقرير"
5. تحقق من نافذة الطباعة

### الخطوة 3: إضافة اختبارات

**ملف:** `server/print-reports.test.ts`

```typescript
import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

describe("Print Reports", () => {
  it("should filter cases by department", async () => {
    // اختبار فلترة الحالات
  });

  it("should generate summary report", async () => {
    // اختبار التقرير المختصر
  });

  it("should generate detailed report", async () => {
    // اختبار التقرير التفصيلي
  });

  it("should generate statistics report", async () => {
    // اختبار تقرير الإحصائيات
  });
});
```

### الخطوة 4: تحسين معالجة الأخطاء

**في BulkImport.tsx:**

```typescript
const handleImport = async () => {
  try {
    // محاولة الاستيراد
    const result = await importMutation.mutateAsync(selectedCases);
    
    if (result.failed.length > 0) {
      toast.error(
        `❌ فشل استيراد ${result.failed.length} حالة:\n${result.failed.map(f => f.reason).join("\n")}`
      );
    } else {
      toast.success(`✅ تم استيراد ${result.success.length} حالة بنجاح`);
    }
  } catch (error) {
    toast.error(`❌ خطأ: ${error.message}`);
  }
};
```

---

## 📦 الملفات المرفقة

1. **DOCUMENTATION.md** - التوثيق الشامل للنظام
2. **PROJECT_STRUCTURE.md** - هيكل المشروع
3. **med-cases-manager-code.zip** - نسخة من الكود الرئيسي

---

## 🔗 الروابط المهمة

- **الموقع الحي:** https://medcaseapp-fb4j8g5b.manus.space
- **الصفحة الرئيسية:** `/`
- **لوحة التحكم:** `/dashboard`
- **إضافة حالة:** `/add-case`
- **إدخال جماعي:** `/bulk-import`
- **طباعة التقارير:** `/print-reports`
- **تسجيل دخول المؤسس:** `/founder-login`

---

## 💡 نصائح مهمة

1. **استخدم الإدخال الجماعي للبيانات المتعددة** - أسرع وأسهل
2. **استخدم AI لتحليل البيانات غير المنظمة** - أكثر دقة
3. **تحقق من البيانات قبل الاستيراد** - تجنب الأخطاء
4. **احفظ النسخ الاحتياطية بانتظام** - حماية البيانات
5. **استخدم البحث المتقدم للبحث السريع** - توفير الوقت

---

## 🆘 استكشاف الأخطاء

### ❌ خطأ: "يرجى اختيار قسم واحد على الأقل"
**الحل:** تأكد من اختيار قسم واحد على الأقل قبل الطباعة

### ❌ خطأ: "حدث خطأ أثناء إعداد التقرير"
**الحل:** تحقق من اتصالك بالإنترنت وحاول مرة أخرى

### ❌ خطأ: "فشل استيراد الحالات"
**الحل:** تحقق من صيغة البيانات وتأكد من صحة المعلومات

---

## 📞 الدعم

للمساعدة أو الإبلاغ عن مشاكل:
- تواصل مع فريق التطوير
- افتح issue على GitHub
- أرسل بريد إلى support@example.com

---

**آخر تحديث:** 10 يوليو 2026  
**الإصدار:** 2.0  
**الحالة:** ✅ جاهز للاستخدام والاستكمال
