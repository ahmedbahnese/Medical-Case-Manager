# 🏗️ هيكل المشروع - نظام إدارة الحالات الطبية BSCH

## 📂 بنية المجلدات

```
med-cases-manager/
├── client/                          # تطبيق الويب (Frontend)
│   ├── src/
│   │   ├── pages/                  # صفحات التطبيق
│   │   │   ├── Home.tsx            # الصفحة الرئيسية
│   │   │   ├── AddCase.tsx         # إضافة حالة جديدة
│   │   │   ├── BulkImport.tsx      # الإدخال الجماعي
│   │   │   ├── Department.tsx      # عرض القسم
│   │   │   ├── Search.tsx          # البحث المتقدم
│   │   │   ├── FounderLogin.tsx    # تسجيل دخول المؤسس
│   │   │   └── NotFound.tsx        # صفحة 404
│   │   ├── components/             # مكونات React
│   │   │   ├── DashboardLayout.tsx # تخطيط لوحة التحكم
│   │   │   ├── AIChatBox.tsx       # صندوق الدردشة AI
│   │   │   ├── Map.tsx             # خريطة Google
│   │   │   └── ui/                 # مكونات shadcn/ui
│   │   ├── lib/
│   │   │   ├── trpc.ts             # عميل tRPC
│   │   │   └── utils.ts            # دوال مساعدة
│   │   ├── App.tsx                 # مكون التطبيق الرئيسي
│   │   ├── main.tsx                # نقطة الدخول
│   │   └── index.css               # الأنماط العامة
│   ├── public/                     # ملفات عامة
│   ├── index.html                  # صفحة HTML الرئيسية
│   └── vite.config.ts              # إعدادات Vite
│
├── server/                         # خادم الويب (Backend)
│   ├── routers.ts                  # إجراءات tRPC
│   ├── db.ts                       # دوال قاعدة البيانات
│   ├── auth.logout.test.ts         # اختبارات التوثيق
│   ├── storage.ts                  # إدارة التخزين
│   └── _core/                      # ملفات أساسية
│       ├── index.ts                # نقطة دخول الخادم
│       ├── context.ts              # سياق tRPC
│       ├── trpc.ts                 # إعدادات tRPC
│       ├── oauth.ts                # OAuth
│       ├── llm.ts                  # تكامل LLM
│       ├── env.ts                  # متغيرات البيئة
│       └── ...                     # ملفات أخرى
│
├── drizzle/                        # إدارة قاعدة البيانات
│   ├── schema.ts                   # تعريف الجداول
│   ├── migrations/                 # ملفات الترحيل
│   └── relations.ts                # العلاقات بين الجداول
│
├── shared/                         # كود مشترك
│   ├── const.ts                    # الثوابت
│   └── types.ts                    # أنواع TypeScript
│
├── references/                     # توثيق التكاملات
│   ├── llm-integration.md          # تكامل LLM
│   ├── file-storage.md             # تخزين الملفات
│   ├── image-generation.md         # توليد الصور
│   └── ...                         # توثيق أخرى
│
├── DOCUMENTATION.md                # التوثيق الشامل
├── package.json                    # اعتماديات المشروع
├── tsconfig.json                   # إعدادات TypeScript
├── vite.config.ts                  # إعدادات Vite
└── vitest.config.ts                # إعدادات الاختبارات
```

## 🔑 الملفات الرئيسية

### Frontend Pages

| الملف | الوصف | المسار |
|------|-------|--------|
| `Home.tsx` | الصفحة الرئيسية مع الإحصائيات | `/` |
| `AddCase.tsx` | إضافة حالة جديدة | `/add-case` |
| `BulkImport.tsx` | الإدخال الجماعي مع AI | `/bulk-import` |
| `Department.tsx` | عرض تفاصيل القسم | `/departments/:id` |
| `Search.tsx` | البحث المتقدم | `/search` |
| `FounderLogin.tsx` | تسجيل دخول المؤسس | `/founder-login` |

### Backend Routes

| الإجراء | الوصف |
|--------|-------|
| `departments.list` | قائمة جميع الأقسام |
| `cases.create` | إنشاء حالة جديدة |
| `cases.getByDepartment` | الحالات حسب القسم |
| `cases.search` | البحث المتقدم |
| `ai.analyzeBulkData` | تحليل البيانات بـ AI |
| `auth.founderLogin` | تسجيل دخول المؤسس |

### Database Schema

| الجدول | الحقول |
|-------|--------|
| `departments` | id, name, capacity, description |
| `patients` | id, name, parentName, parentPhone, nationalId, fileNumber |
| `medical_cases` | id, patientId, departmentId, diagnosis, symptoms, treatment, notes, caseType, artificialRespiration, createdBy, createdAt, updatedAt |
| `waiting_cases` | id, patientName, departmentId, status, createdAt |
| `backups` | id, data, createdAt |

## 🚀 البدء السريع

### التثبيت

```bash
# استنساخ المشروع
git clone <repository-url>
cd med-cases-manager

# تثبيت الاعتماديات
pnpm install

# تشغيل الخادم الإنمائي
pnpm dev
```

### الوصول إلى التطبيق

- **URL**: http://localhost:3000
- **الصفحة الرئيسية**: http://localhost:3000/
- **إضافة حالة**: http://localhost:3000/add-case
- **إدخال جماعي**: http://localhost:3000/bulk-import

## 🔧 الأوامر المهمة

```bash
# تشغيل الخادم الإنمائي
pnpm dev

# بناء التطبيق
pnpm build

# تشغيل الاختبارات
pnpm test

# التحقق من TypeScript
pnpm type-check

# تنسيق الكود
pnpm format

# إنشاء ترحيل قاعدة البيانات
pnpm drizzle-kit generate

# تطبيق الترحيل
pnpm drizzle-kit migrate
```

## 📦 الاعتماديات الرئيسية

### Frontend
- **React 19**: مكتبة واجهات المستخدم
- **Tailwind CSS 4**: أنماط CSS
- **shadcn/ui**: مكونات جاهزة
- **tRPC**: اتصال آمن بالخادم
- **Wouter**: توجيه الصفحات
- **Sonner**: إشعارات

### Backend
- **Express 4**: خادم الويب
- **tRPC 11**: واجهة برمجية آمنة
- **Drizzle ORM**: إدارة قاعدة البيانات
- **Zod**: التحقق من البيانات
- **LLM API**: تحليل البيانات بـ AI

## 🧪 الاختبارات

```bash
# تشغيل جميع الاختبارات
pnpm test

# تشغيل اختبار معين
pnpm test auth.logout.test.ts

# مراقبة الاختبارات
pnpm test --watch
```

## 📝 المتغيرات البيئية

```env
# قاعدة البيانات
DATABASE_URL=mysql://user:password@localhost/dbname

# المصادقة
JWT_SECRET=your-secret-key
FOUNDER_PASSWORD=your-founder-password

# OAuth
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://oauth.manus.im

# API
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=your-api-key
```

## 🎨 معايير الكود

- **TypeScript**: صارم مع فحص الأنواع
- **ESLint**: فحص الكود
- **Prettier**: تنسيق الكود
- **Tailwind CSS**: أنماط موحدة
- **React Best Practices**: أفضل الممارسات

## 📊 الأداء

- ⚡ تحميل سريع (< 2s)
- 🔄 تحديثات فورية
- 📱 متوافق مع الهاتف
- ♿ سهل الوصول
- 🔒 آمن وموثوق

## 🤝 المساهمة

لإضافة ميزة جديدة:

1. أنشئ فرع جديد
2. أضف الميزة مع الاختبارات
3. تأكد من مطابقة معايير الكود
4. أرسل طلب دمج

## 📞 الدعم

للمساعدة أو الإبلاغ عن مشاكل:
- تواصل مع فريق التطوير
- افتح issue على GitHub
- أرسل بريد إلى support@example.com

---

**آخر تحديث:** 10 يوليو 2026
**الإصدار:** 2.0
