import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import { 
  getAllDepartments, getMedicalCasesByDepartmentId, createMedicalCase, getDepartmentById, 
  createPatient, updateMedicalCase, deleteMedicalCase, getAllWaitingCases, getWaitingCasesBySection,
  createWaitingCase, updateWaitingCase, deleteWaitingCase, createBackup, getAllBackups
} from "./db";
import { z } from "zod";

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    founderLogin: publicProcedure
      .input(z.object({ password: z.string() }))
      .mutation(({ input, ctx }) => {
        const founderPassword = process.env.FOUNDER_PASSWORD;
        if (!founderPassword) {
          throw new Error('Founder password not configured');
        }
        
        if (input.password !== founderPassword) {
          throw new Error('Invalid founder password');
        }
        
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, 'founder_session', {
          ...cookieOptions,
          maxAge: 24 * 60 * 60 * 1000,
        });
        
        return {
          success: true,
          isFounder: true,
        } as const;
      }),
  }),

  // Departments routes
  departments: router({
    list: publicProcedure.query(async () => {
      return await getAllDepartments();
    }),
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return await getDepartmentById(input.id);
    }),
  }),

  // Medical cases routes
  cases: router({
    getByDepartment: publicProcedure.input(z.object({ departmentId: z.number() })).query(async ({ input }) => {
      return await getMedicalCasesByDepartmentId(input.departmentId);
    }),
    search: publicProcedure
      .input(
        z.object({
          patientName: z.string().optional(),
          nationalId: z.string().optional(),
          fileNumber: z.string().optional(),
          departmentId: z.number().optional(),
          status: z.string().optional(),
          artificialRespiration: z.string().optional(),
        })
      )
      .query(async ({ input }) => {
        const allCases = [];
        for (let i = 1; i <= 6; i++) {
          const cases = await getMedicalCasesByDepartmentId(i);
          allCases.push(...cases);
        }

        return allCases.filter((caseData: any) => {
          if (input.patientName && !caseData.patientName?.toLowerCase().includes(input.patientName.toLowerCase())) {
            return false;
          }
          if (input.nationalId && !caseData.nationalId?.includes(input.nationalId)) {
            return false;
          }
          if (input.fileNumber && !caseData.fileNumber?.includes(input.fileNumber)) {
            return false;
          }
          if (input.departmentId && caseData.departmentId !== input.departmentId) {
            return false;
          }
          if (input.status && caseData.status !== input.status) {
            return false;
          }
          if (input.artificialRespiration && input.artificialRespiration !== "all" && caseData.artificialRespiration !== input.artificialRespiration) {
            return false;
          }
          return true;
        });
      }),
    getRespirationCases: publicProcedure.query(async () => {
      const allCases = [];
      for (let i = 1; i <= 6; i++) {
        const cases = await getMedicalCasesByDepartmentId(i);
        allCases.push(...cases);
      }
      return allCases.filter((caseData: any) => caseData.artificialRespiration && caseData.artificialRespiration !== "no");
    }),
    create: protectedProcedure
      .input(
        z.object({
          patientName: z.string(),
          departmentId: z.number(),
          diagnosis: z.string().optional(),
          symptoms: z.string().optional(),
          treatment: z.string().optional(),
          notes: z.string().optional(),
          parentName: z.string().optional(),
          parentPhone: z.string().optional(),
          nationalId: z.string().optional(),
          fileNumber: z.string().optional(),
          caseType: z.enum(["intensive_care_high", "intensive_care_medium", "picu", "incubator"]).optional(),
          artificialRespiration: z.enum(["high_frequency", "vent", "cpap", "standby", "no"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Create patient first
        const patientResult = await createPatient({
          name: input.patientName,
          parentName: input.parentName,
          parentPhone: input.parentPhone,
          nationalId: input.nationalId,
          fileNumber: input.fileNumber,
        });

        // Get the patient ID from the insert result
        // mysql2 returns [ResultSetHeader, fields], so we access [0].insertId
        const patientId = (patientResult as any)[0]?.insertId || (patientResult as any).insertId;

        if (!patientId) {
          throw new Error("فشل الحصول على معرف المريض بعد الإنشاء");
        }

        // Create medical case
        const caseResult = await createMedicalCase({
          patientId,
          departmentId: input.departmentId,
          diagnosis: input.diagnosis,
          symptoms: input.symptoms,
          treatment: input.treatment,
          notes: input.notes,
          caseType: input.caseType,
          artificialRespiration: input.artificialRespiration,
          createdBy: ctx.user.id,
        });

        return caseResult;
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          diagnosis: z.string().optional(),
          symptoms: z.string().optional(),
          treatment: z.string().optional(),
          notes: z.string().optional(),
          status: z.enum(["active", "recovering", "discharged", "critical"]).optional(),
          artificialRespiration: z.enum(["high_frequency", "vent", "cpap", "standby", "no"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await updateMedicalCase(id, updates);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteMedicalCase(input.id);
      }),
  }),

  // Waiting cases routes
  waitingCases: router({
    list: publicProcedure.query(async () => {
      return await getAllWaitingCases();
    }),
    getBySection: publicProcedure.input(z.object({ section: z.enum(["servo", "reception"]) })).query(async ({ input }) => {
      return await getWaitingCasesBySection(input.section);
    }),
    create: protectedProcedure
      .input(
        z.object({
          patientName: z.string(),
          age: z.string().optional(),
          diagnosis: z.string().optional(),
          parentPhone: z.string().optional(),
          nationalId: z.string().optional(),
          careType: z.enum(["intensive_care_high", "intensive_care_medium", "picu", "incubator"]),
          centralRoomRequired: z.boolean().optional(),
          centralRoomCode: z.string().optional(),
          artificialRespiration: z.enum(["high_frequency", "vent", "cpap", "standby", "no"]).optional(),
          section: z.enum(["servo", "reception"]).optional(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await createWaitingCase({
          patientName: input.patientName,
          age: input.age,
          diagnosis: input.diagnosis,
          parentPhone: input.parentPhone,
          nationalId: input.nationalId,
          careType: input.careType,
          centralRoomRequired: input.centralRoomRequired,
          centralRoomCode: input.centralRoomCode,
          artificialRespiration: input.artificialRespiration,
          section: input.section,
          createdBy: ctx.user.id,
        });
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          status: z.enum(["waiting", "admitted", "cancelled"]).optional(),
          section: z.enum(["servo", "reception"]).optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        return await updateWaitingCase(id, updates);
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteWaitingCase(input.id);
      }),
  }),

  // Backup routes
  backup: router({
    list: publicProcedure.query(async () => {
      return await getAllBackups();
    }),
    create: protectedProcedure
      .input(
        z.object({
          backupName: z.string(),
          backupData: z.string(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        return await createBackup({
          backupName: input.backupName,
          backupData: input.backupData,
          createdBy: ctx.user.id,
        });
      }),
  }),

  // AI Analysis for bulk import
  ai: router({
    analyzeBulkData: publicProcedure
      .input(
        z.object({
          text: z.string(),
          departmentId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: `أنت مساعد متخصص في تحليل بيانات المرضى الطبية. قم بتحليل النص المدخل واستخراج المعلومات الطبية منه.

يجب أن تستخرج المعلومات التالية إن وجدت:
- اسم المريض (patientName)
- السن (age)
- التشخيص (diagnosis)
- الأعراض (symptoms)
- رقم الهاتف (parentPhone)
- الرقم القومي (nationalId)
- ملاحظات إضافية (notes)
- نوع الرعاية: intensive_care_high, intensive_care_medium, picu, incubator (careType)
- نوع التنفس الصناعي: no, high_frequency, vent, cpap, standby (artificialRespiration)

أرجع النتيجة كـ JSON بدون markdown wrapper.`,
              },
              {
                role: "user",
                content: input.text as string,
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "medical_data_analysis",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    cases: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          patientName: { type: "string" },
                          age: { type: "string" },
                          diagnosis: { type: "string" },
                          symptoms: { type: "string" },
                          parentPhone: { type: "string" },
                          nationalId: { type: "string" },
                          notes: { type: "string" },
                          careType: { type: "string" },
                          artificialRespiration: { type: "string" },
                        },
                        required: ["patientName"],
                      },
                    },
                  },
                  required: ["cases"],
                  additionalProperties: false,
                },
              },
            },
          });

          const content = response.choices[0].message.content;
          const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
          const parsed = JSON.parse(contentStr);
          return (parsed.cases || []) as any[];
        } catch (error) {
          console.error("AI Analysis Error:", error);
          throw new Error("فشل تحليل البيانات بـ AI");
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
