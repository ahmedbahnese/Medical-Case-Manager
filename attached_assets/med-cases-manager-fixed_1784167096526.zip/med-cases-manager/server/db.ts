import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, departments, patients, InsertPatient, medicalCases, InsertMedicalCase,
  waitingCases, InsertWaitingCase, backupRecords, InsertBackupRecord
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Departments queries
export async function getAllDepartments() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(departments);
}

export async function getDepartmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(departments).where(eq(departments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDepartment(department: any) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.insert(departments).values(department);
}

// Patients queries
export async function getAllPatients() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(patients);
}

export async function getPatientById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(patients).where(eq(patients.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPatient(patient: InsertPatient) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  // Using raw insert to ensure we get the insertId reliably with mysql2
  const result = await db.insert(patients).values(patient);
  
  // Drizzle with mysql2 returns an array where the first element is the result object
  // containing insertId, affectedRows, etc.
  return result;
}

// Medical cases queries
export async function getMedicalCasesByDepartmentId(departmentId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(medicalCases).where(eq(medicalCases.departmentId, departmentId));
}

export async function getMedicalCaseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(medicalCases).where(eq(medicalCases.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createMedicalCase(medicalCase: InsertMedicalCase) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  
  // Ensure all required fields are present
  if (!medicalCase.patientId || !medicalCase.departmentId || !medicalCase.createdBy) {
    throw new Error('Missing required fields: patientId, departmentId, or createdBy');
  }
  
  // Map fields to ensure they match schema expectations and provide defaults if needed
  const values: InsertMedicalCase = {
    patientId: medicalCase.patientId,
    departmentId: medicalCase.departmentId,
    diagnosis: medicalCase.diagnosis || null,
    symptoms: medicalCase.symptoms || null,
    treatment: medicalCase.treatment || null,
    notes: medicalCase.notes || null,
    caseType: medicalCase.caseType || "intensive_care_high",
    artificialRespiration: medicalCase.artificialRespiration || "no",
    status: medicalCase.status || "active",
    createdBy: medicalCase.createdBy,
  };
  
  const result = await db.insert(medicalCases).values(values);
  return result;
}

export async function updateMedicalCase(id: number, updates: Partial<InsertMedicalCase>) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.update(medicalCases).set(updates).where(eq(medicalCases.id, id));
}

export async function deleteMedicalCase(id: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.delete(medicalCases).where(eq(medicalCases.id, id));
}

// Waiting cases queries
export async function getAllWaitingCases() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(waitingCases);
}

export async function getWaitingCasesBySection(section: "servo" | "reception") {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(waitingCases).where(eq(waitingCases.section, section));
}

export async function createWaitingCase(waitingCase: InsertWaitingCase) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.insert(waitingCases).values(waitingCase);
}

export async function updateWaitingCase(id: number, updates: Partial<InsertWaitingCase>) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.update(waitingCases).set(updates).where(eq(waitingCases.id, id));
}

export async function deleteWaitingCase(id: number) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.delete(waitingCases).where(eq(waitingCases.id, id));
}

// Backup queries
export async function createBackup(backup: InsertBackupRecord) {
  const db = await getDb();
  if (!db) throw new Error('Database not available');
  return await db.insert(backupRecords).values(backup);
}

export async function getAllBackups() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(backupRecords);
}

export async function getBackupById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(backupRecords).where(eq(backupRecords.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
