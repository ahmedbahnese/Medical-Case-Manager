import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Medical departments table - 6 departments (عناية كبيرة، عناية متوسطة، بيكيو، حضانات أ، ب، ج)
 */
export const departments = mysqlTable("departments", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(), // "عناية كبيرة", "بيكيو", etc.
  code: varchar("code", { length: 10 }).notNull().unique(), // "ICU_HIGH", "PICU", "INC_A", etc.
  description: text("description"),
  capacity: int("capacity").default(10),
  departmentType: mysqlEnum("departmentType", ["intensive_care_high", "intensive_care_medium", "picu", "incubator_a", "incubator_b", "incubator_c"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Department = typeof departments.$inferSelect;
export type InsertDepartment = typeof departments.$inferInsert;

/**
 * Patients table - stores patient information
 */
export const patients = mysqlTable("patients", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  dateOfBirth: timestamp("dateOfBirth"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  nationalId: varchar("nationalId", { length: 20 }), // رقم قومي
  fileNumber: varchar("fileNumber", { length: 50 }), // رقم ملف
  parentName: varchar("parentName", { length: 255 }),
  parentPhone: varchar("parentPhone", { length: 20 }),
  medicalHistory: text("medicalHistory"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Patient = typeof patients.$inferSelect;
export type InsertPatient = typeof patients.$inferInsert;

/**
 * Medical cases table - stores medical cases for patients in departments
 */
export const medicalCases = mysqlTable("medical_cases", {
  id: int("id").autoincrement().primaryKey(),
  patientId: int("patientId").notNull(),
  departmentId: int("departmentId").notNull(),
  diagnosis: text("diagnosis"),
  symptoms: text("symptoms"),
  treatment: text("treatment"),
  notes: text("notes"),
  caseType: mysqlEnum("caseType", ["intensive_care_high", "intensive_care_medium", "picu", "incubator"]).default("intensive_care_high"),
  artificialRespiration: mysqlEnum("artificialRespiration", ["high_frequency", "vent", "cpap", "standby", "no"]).default("no"), // تنفس صناعي
  status: mysqlEnum("status", ["active", "recovering", "discharged", "critical"]).default("active"),
  admissionDate: timestamp("admissionDate").defaultNow().notNull(),
  dischargeDate: timestamp("dischargeDate"),
  createdBy: int("createdBy").notNull(), // user who created the case
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MedicalCase = typeof medicalCases.$inferSelect;
export type InsertMedicalCase = typeof medicalCases.$inferInsert;

/**
 * Waiting cases table - stores cases waiting for admission
 */
export const waitingCases = mysqlTable("waiting_cases", {
  id: int("id").autoincrement().primaryKey(),
  patientName: varchar("patientName", { length: 255 }).notNull(),
  age: varchar("age", { length: 50 }),
  diagnosis: text("diagnosis"),
  parentPhone: varchar("parentPhone", { length: 20 }),
  nationalId: varchar("nationalId", { length: 20 }),
  careType: mysqlEnum("careType", ["intensive_care_high", "intensive_care_medium", "picu", "incubator"]).notNull(),
  centralRoomRequired: boolean("centralRoomRequired").default(false),
  centralRoomCode: varchar("centralRoomCode", { length: 50 }),
  artificialRespiration: mysqlEnum("artificialRespiration", ["high_frequency", "vent", "cpap", "standby", "no"]).default("no"),
  section: mysqlEnum("section", ["servo", "reception"]).default("reception"), // سيرفو أو استقبال
  status: mysqlEnum("status", ["waiting", "admitted", "cancelled"]).default("waiting"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type WaitingCase = typeof waitingCases.$inferSelect;
export type InsertWaitingCase = typeof waitingCases.$inferInsert;

/**
 * Backup records table - stores backup data
 */
export const backupRecords = mysqlTable("backup_records", {
  id: int("id").autoincrement().primaryKey(),
  backupName: varchar("backupName", { length: 255 }).notNull(),
  backupData: text("backupData").notNull(), // JSON data
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BackupRecord = typeof backupRecords.$inferSelect;
export type InsertBackupRecord = typeof backupRecords.$inferInsert;
