import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, useLocation } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import DepartmentDetail from "./pages/DepartmentDetail";
import AddCase from "./pages/AddCase";
import CaseDetail from "./pages/CaseDetail";
import WaitingCases from "./pages/WaitingCases";
import ArtificialRespiration from "./pages/ArtificialRespiration";
import BulkImport from "./pages/BulkImport";
import AdvancedSearch from "./pages/AdvancedSearch";
import PrintReport from "./pages/PrintReport";
import Backup from "./pages/Backup";
import ExportReports from "./pages/ExportReports";
import PrintReports from "./pages/PrintReports";
import FounderLogin from "./pages/FounderLogin";
import { useAuth } from "@/_core/hooks/useAuth";
import { useEffect } from "react";

function Router() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  // Auto-redirect to dashboard if user is logged in and on home page
  useEffect(() => {
    if (!loading && user) {
      const currentPath = window.location.pathname;
      if (currentPath === "/") {
        setLocation("/dashboard");
      }
    }
  }, [user, loading, setLocation]);

  return (
    <Switch>
      <Route path={"/"}>
        <Home />
      </Route>
      <Route path={"/dashboard"}>
        <Dashboard />
      </Route>
      <Route path={"/departments/:id"}>
        <DepartmentDetail />
      </Route>
      <Route path={"/rooms/:id"}>
        <DepartmentDetail />
      </Route>
      <Route path={"/add-case"}>
        <AddCase />
      </Route>
      <Route path={"/case/:id"}>
        <CaseDetail />
      </Route>
      <Route path={"/waiting-cases"}>
        <WaitingCases />
      </Route>
      <Route path={"/artificial-respiration"}>
        <ArtificialRespiration />
      </Route>
      <Route path={"/bulk-import"}>
        <BulkImport />
      </Route>
      <Route path={"/advanced-search"}>
        <AdvancedSearch />
      </Route>
      <Route path={"/print-report"}>
        <PrintReport />
      </Route>
      <Route path={"/backup"}>
        <Backup />
      </Route>
      <Route path={"/export-reports"}>
        <ExportReports />
      </Route>
      <Route path={"/print-reports"}>
        <PrintReports />
      </Route>
      <Route path={"/founder-login"}>
        <FounderLogin />
      </Route>
      <Route path={"/404"}>
        <NotFound />
      </Route>
      {/* Final fallback route */}
      <Route>
        <NotFound />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
