import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { ArrowRight, CheckCircle, Plus } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function AddCase() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: departments } = trpc.departments.list.useQuery();
  const createCaseMutation = trpc.cases.create.useMutation();

  const [formData, setFormData] = useState({
    patientName: "",
    departmentId: 0,
    age: "",
    diagnosis: "",
    symptoms: "",
    treatment: "",
    notes: "",
    parentName: "",
    parentPhone: "",
    nationalId: "",
    fileNumber: "",
    caseType: "intensive_care_high" as const,
    artificialRespiration: "no" as const,
  });

  const [confirmChecklist, setConfirmChecklist] = useState({
    patientNameConfirmed: false,
    departmentConfirmed: false,
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  const isChecklistComplete = Object.values(confirmChecklist).every(v => v === true);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.patientName.trim()) {
      toast.error("❌ يرجى إدخال اسم الحالة");
      return;
    }

    if (!formData.departmentId) {
      toast.error("❌ يرجى اختيار المكان/القسم");
      return;
    }

    if (!isChecklistComplete) {
      toast.error("❌ يرجى تأكيد البيانات قبل الإدخال");
      return;
    }

    try {
      await createCaseMutation.mutateAsync({
        patientName: formData.patientName,
        departmentId: formData.departmentId,
        diagnosis: formData.diagnosis || "",
        symptoms: formData.symptoms || "",
        treatment: formData.treatment || "",
        notes: formData.notes || "",
        parentName: formData.parentName || "",
        parentPhone: formData.parentPhone || "",
        nationalId: formData.nationalId || "",
        fileNumber: formData.fileNumber || "",
        caseType: formData.caseType,
        artificialRespiration: formData.artificialRespiration,
      });
      toast.success("✅ تم إدخال الحالة بنجاح!");
      setLocation(`/departments/${formData.departmentId}`);
    } catch (error: any) {
      const errorMsg = error?.message || "حدث خطأ أثناء إدخال الحالة";
      toast.error(`❌ ${errorMsg}`);
      console.error(error);
    }
  };

  // Get department name
  const departmentName = departments?.find((d: any) => d.id === formData.departmentId)?.name || "غير محدد";

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            العودة
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-gray-900">➕ إدخال حالة جديدة</h1>
            <p className="text-gray-600 mt-1">أدخل اسم الحالة والمكان فقط - البيانات الأخرى اختيارية</p>
          </div>
        </div>

        {/* Form Card */}
        <Card className="border-0 shadow-lg">
          <CardHeader className="bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-t-lg">
            <CardTitle className="text-2xl flex items-center gap-2">
              <Plus className="w-6 h-6" />
              إدخال البيانات الأساسية
            </CardTitle>
            <CardDescription className="text-green-100">
              الحقول المطلوبة: اسم الحالة والمكان فقط
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Essential Information Section */}
              <div className="bg-green-50 border-2 border-green-200 rounded-lg p-4 space-y-4">
                <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  البيانات الأساسية المطلوبة
                </h3>

                {/* Patient Name */}
                <div className="space-y-2">
                  <Label htmlFor="patientName" className="text-gray-900 font-bold">
                    اسم الحالة *
                  </Label>
                  <Input
                    id="patientName"
                    placeholder="مثال: أحمد محمد / التهاب رئوي حاد"
                    value={formData.patientName}
                    onChange={(e) =>
                      setFormData({ ...formData, patientName: e.target.value })
                    }
                    required
                    className="border-2 border-green-300 focus:border-green-600 text-lg"
                  />
                  <p className="text-sm text-gray-600">يمكن إدخال اسم المريض أو اسم الحالة الطبية</p>
                </div>

                {/* Department Selection */}
                <div className="space-y-2">
                  <Label htmlFor="departmentId" className="text-gray-900 font-bold">
                    المكان / القسم *
                  </Label>
                  <Select
                    value={formData.departmentId.toString()}
                    onValueChange={(value) =>
                      setFormData({ ...formData, departmentId: parseInt(value) })
                    }
                  >
                    <SelectTrigger className="border-2 border-green-300 focus:border-green-600 text-lg">
                      <SelectValue placeholder="اختر المكان / القسم" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments?.map((department: any) => (
                        <SelectItem key={department.id} value={department.id.toString()}>
                          {department.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Summary */}
                {formData.patientName && formData.departmentId > 0 && (
                  <div className="bg-white border border-green-300 rounded p-3">
                    <p className="text-sm text-gray-700">
                      <strong>📋 ملخص البيانات:</strong> {formData.patientName} | المكان: {departmentName}
                    </p>
                  </div>
                )}
              </div>

              {/* Confirmation Checklist */}
              <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 space-y-3">
                <h3 className="text-lg font-semibold text-gray-900">✓ تأكيد البيانات</h3>
                
                <div className="flex items-center gap-3 p-2 hover:bg-blue-100 rounded cursor-pointer">
                  <Checkbox
                    id="patientNameConfirmed"
                    checked={confirmChecklist.patientNameConfirmed}
                    onCheckedChange={(checked) =>
                      setConfirmChecklist({
                        ...confirmChecklist,
                        patientNameConfirmed: checked as boolean,
                      })
                    }
                  />
                  <label htmlFor="patientNameConfirmed" className="cursor-pointer text-gray-700">
                    ✅ تأكيد اسم الحالة صحيح: <strong>{formData.patientName || "لم يتم إدخاله"}</strong>
                  </label>
                </div>

                <div className="flex items-center gap-3 p-2 hover:bg-blue-100 rounded cursor-pointer">
                  <Checkbox
                    id="departmentConfirmed"
                    checked={confirmChecklist.departmentConfirmed}
                    onCheckedChange={(checked) =>
                      setConfirmChecklist({
                        ...confirmChecklist,
                        departmentConfirmed: checked as boolean,
                      })
                    }
                  />
                  <label htmlFor="departmentConfirmed" className="cursor-pointer text-gray-700">
                    ✅ تأكيد المكان صحيح: <strong>{departmentName}</strong>
                  </label>
                </div>
              </div>

              {/* Advanced Options Toggle */}
              <div className="border-t pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAdvanced(!showAdvanced)}
                  className="w-full text-gray-700"
                >
                  {showAdvanced ? "▼ إخفاء البيانات الإضافية" : "▶ إضافة بيانات إضافية (اختياري)"}
                </Button>
              </div>

              {/* Advanced Information Section */}
              {showAdvanced && (
                <div className="bg-gray-50 border border-gray-300 rounded-lg p-4 space-y-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">📝 بيانات إضافية (اختيارية)</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Age */}
                    <div className="space-y-2">
                      <Label htmlFor="age" className="text-gray-700">السن</Label>
                      <Input
                        id="age"
                        placeholder="أدخل السن"
                        value={formData.age}
                        onChange={(e) =>
                          setFormData({ ...formData, age: e.target.value })
                        }
                        className="border-gray-300"
                      />
                    </div>

                    {/* National ID */}
                    <div className="space-y-2">
                      <Label htmlFor="nationalId" className="text-gray-700">الرقم القومي</Label>
                      <Input
                        id="nationalId"
                        placeholder="أدخل الرقم القومي"
                        value={formData.nationalId}
                        onChange={(e) =>
                          setFormData({ ...formData, nationalId: e.target.value })
                        }
                        className="border-gray-300"
                      />
                    </div>

                    {/* File Number */}
                    <div className="space-y-2">
                      <Label htmlFor="fileNumber" className="text-gray-700">رقم الملف</Label>
                      <Input
                        id="fileNumber"
                        placeholder="أدخل رقم الملف"
                        value={formData.fileNumber}
                        onChange={(e) =>
                          setFormData({ ...formData, fileNumber: e.target.value })
                        }
                        className="border-gray-300"
                      />
                    </div>

                    {/* Parent Name */}
                    <div className="space-y-2">
                      <Label htmlFor="parentName" className="text-gray-700">اسم الوالد/الوالدة</Label>
                      <Input
                        id="parentName"
                        placeholder="أدخل اسم الوالد"
                        value={formData.parentName}
                        onChange={(e) =>
                          setFormData({ ...formData, parentName: e.target.value })
                        }
                        className="border-gray-300"
                      />
                    </div>

                    {/* Parent Phone */}
                    <div className="space-y-2">
                      <Label htmlFor="parentPhone" className="text-gray-700">رقم الهاتف</Label>
                      <Input
                        id="parentPhone"
                        placeholder="أدخل رقم الهاتف"
                        value={formData.parentPhone}
                        onChange={(e) =>
                          setFormData({ ...formData, parentPhone: e.target.value })
                        }
                        className="border-gray-300"
                      />
                    </div>

                    {/* Care Type */}
                    <div className="space-y-2">
                      <Label htmlFor="caseType" className="text-gray-700">نوع الرعاية</Label>
                      <Select
                        value={formData.caseType}
                        onValueChange={(value: any) =>
                          setFormData({ ...formData, caseType: value })
                        }
                      >
                        <SelectTrigger className="border-gray-300">
                          <SelectValue placeholder="اختر نوع الرعاية" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="intensive_care_high">عناية كبيرة</SelectItem>
                          <SelectItem value="intensive_care_medium">عناية متوسطة</SelectItem>
                          <SelectItem value="picu">بيكيو</SelectItem>
                          <SelectItem value="incubator">محضن</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Artificial Respiration */}
                    <div className="space-y-2">
                      <Label htmlFor="artificialRespiration" className="text-gray-700">التنفس الصناعي</Label>
                      <Select
                        value={formData.artificialRespiration}
                        onValueChange={(value: any) =>
                          setFormData({ ...formData, artificialRespiration: value })
                        }
                      >
                        <SelectTrigger className="border-gray-300">
                          <SelectValue placeholder="اختر حالة التنفس" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="no">لا</SelectItem>
                          <SelectItem value="high_frequency">عالي التردد</SelectItem>
                          <SelectItem value="vent">فينت</SelectItem>
                          <SelectItem value="cpap">سباب</SelectItem>
                          <SelectItem value="standby">استاندباي</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Diagnosis */}
                  <div className="space-y-2">
                    <Label htmlFor="diagnosis" className="text-gray-700">التشخيص</Label>
                    <Input
                      id="diagnosis"
                      placeholder="أدخل التشخيص الطبي"
                      value={formData.diagnosis}
                      onChange={(e) =>
                        setFormData({ ...formData, diagnosis: e.target.value })
                      }
                      className="border-gray-300"
                    />
                  </div>

                  {/* Symptoms */}
                  <div className="space-y-2">
                    <Label htmlFor="symptoms" className="text-gray-700">الأعراض</Label>
                    <Textarea
                      id="symptoms"
                      placeholder="أدخل الأعراض"
                      value={formData.symptoms}
                      onChange={(e) =>
                        setFormData({ ...formData, symptoms: e.target.value })
                      }
                      rows={3}
                      className="border-gray-300"
                    />
                  </div>

                  {/* Treatment */}
                  <div className="space-y-2">
                    <Label htmlFor="treatment" className="text-gray-700">العلاج</Label>
                    <Textarea
                      id="treatment"
                      placeholder="أدخل العلاج"
                      value={formData.treatment}
                      onChange={(e) =>
                        setFormData({ ...formData, treatment: e.target.value })
                      }
                      rows={3}
                      className="border-gray-300"
                    />
                  </div>

                  {/* Notes */}
                  <div className="space-y-2">
                    <Label htmlFor="notes" className="text-gray-700">ملاحظات</Label>
                    <Textarea
                      id="notes"
                      placeholder="أدخل أي ملاحظات إضافية"
                      value={formData.notes}
                      onChange={(e) =>
                        setFormData({ ...formData, notes: e.target.value })
                      }
                      rows={3}
                      className="border-gray-300"
                    />
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <div className="flex gap-4 pt-4 border-t">
                <Button
                  type="submit"
                  disabled={createCaseMutation.isPending || !isChecklistComplete}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white text-lg py-6 flex items-center justify-center gap-2"
                >
                  {createCaseMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      جاري الإدخال...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-5 h-5" />
                      إدخال البيانات
                    </>
                  )}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setLocation("/dashboard")}
                  className="px-8"
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="mt-6 border-0 shadow-lg bg-blue-50">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-gray-900 mb-3">💡 نصائح للاستخدام:</h3>
            <ul className="space-y-2 text-sm text-gray-700">
              <li>✓ أدخل اسم الحالة والمكان فقط - هذا كل ما تحتاجه للبداية</li>
              <li>✓ البيانات الإضافية اختيارية - يمكنك إضافتها لاحقاً</li>
              <li>✓ تأكد من تحديد المكان الصحيح قبل الإدخال</li>
              <li>✓ بعد الإدخال، ستنتقل مباشرة إلى صفحة القسم</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
