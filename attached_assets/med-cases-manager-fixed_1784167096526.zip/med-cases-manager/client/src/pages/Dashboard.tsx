import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { 
  Plus, 
  Users, 
  Building2, 
  Printer, 
  FileSpreadsheet, 
  Search, 
  Activity,
  LayoutDashboard
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: departments } = trpc.departments.list.useQuery();
  const { data: allCases } = trpc.cases.search.useQuery({});
  const { data: waitingCases } = trpc.waitingCases.list.useQuery();

  const stats = {
    totalCases: allCases?.length || 0,
    activeCases: allCases?.filter((c: any) => c.status === "active").length || 0,
    waitingCases: waitingCases?.length || 0,
    departmentsCount: departments?.length || 0,
  };

  const quickActions = [
    {
      title: "إضافة حالة جديدة",
      description: "إدخال بيانات مريض جديد يدوياً",
      icon: <Plus className="w-6 h-6" />,
      color: "bg-blue-600 hover:bg-blue-700",
      action: () => setLocation("/add-case"),
    },
    {
      title: "إدخال جماعي بـ AI",
      description: "تحليل نصوص الحالات وإضافتها تلقائياً",
      icon: <FileSpreadsheet className="w-6 h-6" />,
      color: "bg-green-600 hover:bg-green-700",
      action: () => setLocation("/bulk-import"),
    },
    {
      title: "طباعة التقارير",
      description: "توليد تقارير الأقسام والإحصائيات",
      icon: <Printer className="w-6 h-6" />,
      color: "bg-purple-600 hover:bg-purple-700",
      action: () => setLocation("/print-reports"),
    },
    {
      title: "بحث متقدم",
      description: "البحث عن الحالات بالفلاتر المتقدمة",
      icon: <Search className="w-6 h-6" />,
      color: "bg-orange-600 hover:bg-orange-700",
      action: () => setLocation("/advanced-search"),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
              <LayoutDashboard className="w-8 h-8 text-blue-600" />
              لوحة التحكم
            </h1>
            <p className="text-gray-600 mt-1">مرحباً بك في نظام إدارة الحالات الطبية (BSCH)</p>
          </div>
          <div className="flex items-center gap-3">
            <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
              المستخدم: {user?.name || "زائر"}
            </span>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="border-l-4 border-l-blue-600 shadow-sm">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">إجمالي الحالات</p>
                  <h3 className="text-3xl font-bold text-gray-900">{stats.totalCases}</h3>
                </div>
                <Users className="w-10 h-10 text-blue-200" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-600 shadow-sm">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">حالات نشطة</p>
                  <h3 className="text-3xl font-bold text-gray-900">{stats.activeCases}</h3>
                </div>
                <Activity className="w-10 h-10 text-green-200" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-orange-600 shadow-sm">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">حالات الانتظار</p>
                  <h3 className="text-3xl font-bold text-gray-900">{stats.waitingCases}</h3>
                </div>
                <Users className="w-10 h-10 text-orange-200" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-purple-600 shadow-sm">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">الأقسام</p>
                  <h3 className="text-3xl font-bold text-gray-900">{stats.departmentsCount}</h3>
                </div>
                <Building2 className="w-10 h-10 text-purple-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900">الوصول السريع</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                onClick={action.action}
                className={`${action.color} h-auto py-6 flex flex-col items-center gap-3 text-white rounded-xl shadow-md transition-all hover:scale-105`}
              >
                {action.icon}
                <div className="text-center">
                  <div className="font-bold text-lg">{action.title}</div>
                  <div className="text-xs opacity-90">{action.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {/* Departments Grid */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-gray-900 flex items-center gap-2">
            <Building2 className="w-6 h-6 text-gray-600" />
            الأقسام الطبية
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {departments?.map((dept: any) => (
              <Card key={dept.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => setLocation(`/departments/${dept.id}`)}>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl text-blue-700">{dept.name}</CardTitle>
                  <CardDescription>السعة: {dept.capacity} سرير</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-600">الحالات الحالية:</span>
                    <span className="font-bold text-gray-900">
                      {allCases?.filter((c: any) => c.departmentId === dept.id && c.status === "active").length || 0}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ 
                        width: `${Math.min(100, ((allCases?.filter((c: any) => c.departmentId === dept.id && c.status === "active").length || 0) / dept.capacity) * 100)}%` 
                      }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
