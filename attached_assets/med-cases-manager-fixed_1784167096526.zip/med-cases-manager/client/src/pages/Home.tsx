import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { 
  Activity, 
  Stethoscope, 
  ArrowLeft, 
  ShieldCheck, 
  LayoutDashboard,
  LogOut
} from "lucide-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <Activity className="w-8 h-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">BSCH</span>
            </div>
            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <Button variant="ghost" onClick={() => setLocation("/dashboard")} className="gap-2">
                    <LayoutDashboard className="w-4 h-4" />
                    لوحة التحكم
                  </Button>
                  <Button variant="outline" onClick={() => logout()} className="gap-2 text-red-600 hover:text-red-700">
                    <LogOut className="w-4 h-4" />
                    خروج
                  </Button>
                </>
              ) : (
                <Button onClick={() => setLocation("/dashboard")} className="bg-blue-600 hover:bg-blue-700">
                  دخول النظام
                </Button>
              )}
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="relative overflow-hidden bg-gradient-to-b from-blue-50 to-white pt-16 pb-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 tracking-tight mb-8">
              نظام إدارة الحالات الطبية <br />
              <span className="text-blue-600">الأكثر ذكاءً وتطوراً</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-10 leading-relaxed">
              منصة متكاملة مصممة خصيصاً للمستشفيات والأقسام الطبية لإدارة حالات المرضى، الحضانات، 
              وتحليل البيانات باستخدام الذكاء الاصطناعي.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button 
                size="lg" 
                onClick={() => setLocation("/dashboard")}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-8 text-xl rounded-2xl shadow-xl hover:shadow-2xl transition-all"
              >
                ابدأ الآن مجاناً
                <ArrowLeft className="mr-2 w-6 h-6" />
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => setLocation("/founder-login")}
                className="px-8 py-8 text-xl rounded-2xl border-2"
              >
                دخول المؤسس
                <ShieldCheck className="mr-2 w-6 h-6" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Background Elements */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full pointer-events-none overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
          <div className="absolute top-1/3 right-1/4 w-64 h-64 bg-indigo-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
          <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="p-8 rounded-3xl bg-blue-50 border border-blue-100 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-blue-200">
                <Stethoscope className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">إدارة شاملة للحالات</h3>
              <p className="text-gray-600 leading-relaxed">
                متابعة دقيقة لكل مريض في جميع الأقسام (عناية، حضانات، بيكيو) مع سجل كامل للتشخيص والعلاج.
              </p>
            </div>

            <div className="p-8 rounded-3xl bg-green-50 border border-green-100 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-green-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-green-200">
                <Activity className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">تحليل ذكي بـ AI</h3>
              <p className="text-gray-600 leading-relaxed">
                استخدم قوة الذكاء الاصطناعي لاستخراج البيانات من النصوص الطبية وتوليد تقارير تحليلية دقيقة.
              </p>
            </div>

            <div className="p-8 rounded-3xl bg-purple-50 border border-purple-100 hover:shadow-lg transition-all">
              <div className="w-14 h-14 bg-purple-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg shadow-purple-200">
                <ShieldCheck className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">أمان وموثوقية</h3>
              <p className="text-gray-600 leading-relaxed">
                حماية كاملة لبيانات المرضى مع نظام صلاحيات متطور ودخول آمن للمسؤولين والمؤسس.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center items-center gap-2 mb-6">
            <Activity className="w-6 h-6 text-blue-400" />
            <span className="text-xl font-bold">BSCH</span>
          </div>
          <p className="text-gray-400 mb-8">نظام إدارة الحالات الطبية - مستشفى الأطفال التخصصي</p>
          <div className="border-t border-gray-800 pt-8 text-sm text-gray-500">
            © 2026 جميع الحقوق محفوظة لنظام BSCH
          </div>
        </div>
      </footer>
    </div>
  );
}
