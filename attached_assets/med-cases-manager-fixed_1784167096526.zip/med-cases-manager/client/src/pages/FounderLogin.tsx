import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Hospital } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function FounderLogin() {
  const [password, setPassword] = useState("");
  const [, setLocation] = useLocation();
  const founderLoginMutation = trpc.auth.founderLogin.useMutation();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!password.trim()) {
      toast.error("يرجى إدخال كلمة المرور");
      return;
    }

    try {
      const result = await founderLoginMutation.mutateAsync({ password });
      if (result.success) {
        toast.success("تم تسجيل الدخول بنجاح كمؤسس");
        setLocation("/dashboard");
      }
    } catch (error: any) {
      toast.error(error.message || "فشل تسجيل الدخول");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-2">
          <div className="flex justify-center mb-4">
            <Hospital className="w-12 h-12 text-indigo-600" />
          </div>
          <CardTitle className="text-2xl">تسجيل دخول المؤسس</CardTitle>
          <CardDescription>
            مستشفى الأطفال التخصصي بالبحيرة
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">كلمة المرور</label>
              <Input
                type="password"
                placeholder="أدخل كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={founderLoginMutation.isPending}
                className="text-right"
                dir="rtl"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-indigo-600 hover:bg-indigo-700"
              disabled={founderLoginMutation.isPending}
            >
              {founderLoginMutation.isPending ? "جاري التحقق..." : "تسجيل الدخول"}
            </Button>

            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={() => setLocation("/")}
            >
              العودة للصفحة الرئيسية
            </Button>
          </form>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <p className="text-sm text-gray-600 text-right">
              هذه الصفحة مخصصة لتسجيل دخول المؤسس فقط. يرجى إدخال كلمة المرور الصحيحة.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
