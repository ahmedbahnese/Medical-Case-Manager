import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLocation } from "wouter";
import { ArrowRight, Upload, AlertCircle, CheckCircle, Zap, Loader, Edit2, Save, X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

interface ParsedCase {
  patientName: string;
  age?: string;
  diagnosis?: string;
  symptoms?: string;
  parentPhone?: string;
  nationalId?: string;
  careType: string;
  artificialRespiration: string;
  notes?: string;
}

export default function BulkImport() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [pastedData, setPastedData] = useState("");
  const [parsedCases, setParsedCases] = useState<ParsedCase[]>([]);
  const [importStep, setImportStep] = useState<"input" | "preview" | "edit" | "confirm">("input");
  const [selectedCases, setSelectedCases] = useState<number[]>([]);
  const [selectedDepartmentId, setSelectedDepartmentId] = useState<number>(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [useAI, setUseAI] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingData, setEditingData] = useState<ParsedCase | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  const { data: departments } = trpc.departments.list.useQuery();
  const createCaseMutation = trpc.cases.create.useMutation();
  const analyzeDataMutation = trpc.ai.analyzeBulkData.useMutation();

  const parseData = async () => {
    try {
      setIsAnalyzing(true);

      if (useAI) {
        try {
          const result = await analyzeDataMutation.mutateAsync({
            text: pastedData,
            departmentId: selectedDepartmentId || undefined,
          });

          const cases: ParsedCase[] = result.map((item: any) => ({
            patientName: item.patientName || "",
            age: item.age || "",
            diagnosis: item.diagnosis || "",
            symptoms: item.symptoms || "",
            parentPhone: item.parentPhone || "",
            nationalId: item.nationalId || "",
            careType: item.careType || "intensive_care_high",
            artificialRespiration: item.artificialRespiration || "no",
            notes: item.notes || "",
          }));

          setParsedCases(cases);
          setSelectedCases(cases.map((_, i) => i));
          setImportStep("edit");
          toast.success(`✨ تم تحليل ${cases.length} حالة بنجاح باستخدام الذكاء الاصطناعي`);
        } catch (error: any) {
          console.error("AI Analysis Error:", error);
          const errorMsg = error?.message || "فشل التحليل الذكي";
          toast.error(`❌ ${errorMsg}`);
        }
      } else {
        const lines = pastedData.trim().split("\n");
        const cases: ParsedCase[] = [];
        const seenNames = new Set<string>();
        const duplicates: string[] = [];

        for (const line of lines) {
          if (!line.trim()) continue;

          const parts = line.split(/[,\t]/).map((p) => p.trim());
          if (parts.length < 1) continue;

          const caseData: ParsedCase = {
            patientName: parts[0] || "",
            age: parts[1] || "",
            diagnosis: parts[2] || "",
            parentPhone: parts[3] || "",
            nationalId: parts[4] || "",
            careType: parts[5] || "intensive_care_high",
            artificialRespiration: parts[6] || "no",
            notes: parts[7] || "",
          };

          if (seenNames.has(caseData.patientName)) {
            duplicates.push(caseData.patientName);
          }
          seenNames.add(caseData.patientName);

          if (caseData.patientName) {
            cases.push(caseData);
          }
        }

        if (duplicates.length > 0) {
          toast.warning(`⚠️ تم اكتشاف ${duplicates.length} أسماء مكررة: ${duplicates.join(", ")}`);
        }

        setParsedCases(cases);
        setSelectedCases(cases.map((_, i) => i));
        setImportStep("edit");
        toast.success(`✅ تم تحليل ${cases.length} حالة بنجاح`);
      }
    } catch (error) {
      toast.error("❌ حدث خطأ في تحليل البيانات");
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const startEditingCase = (index: number) => {
    setEditingIndex(index);
    setEditingData({ ...parsedCases[index] });
  };

  const saveEditedCase = () => {
    if (editingIndex !== null && editingData) {
      const newCases = [...parsedCases];
      newCases[editingIndex] = editingData;
      setParsedCases(newCases);
      setEditingIndex(null);
      setEditingData(null);
      toast.success("✅ تم حفظ التعديلات بنجاح");
    }
  };

  const cancelEditing = () => {
    setEditingIndex(null);
    setEditingData(null);
  };

  const handleImport = async () => {
    const casesToImport = selectedCases.map((i) => parsedCases[i]);

    if (casesToImport.length === 0) {
      toast.error("⚠️ يرجى اختيار حالات للاستيراد");
      return;
    }

    if (!selectedDepartmentId) {
      toast.error("⚠️ يرجى اختيار القسم/الغرفة");
      return;
    }

    setIsImporting(true);
    let successCount = 0;
    const failedCases: { name: string; reason: string }[] = [];

    try {
      for (const caseData of casesToImport) {
        try {
          if (!caseData.patientName.trim()) {
            failedCases.push({
              name: "حالة بدون اسم",
              reason: "اسم المريض مطلوب",
            });
            continue;
          }

          const department = departments?.find((d: any) => d.id === selectedDepartmentId);

          if (!department) {
            failedCases.push({
              name: caseData.patientName,
              reason: "لم يتم العثور على القسم المحدد",
            });
            continue;
          }

          await createCaseMutation.mutateAsync({
            patientName: caseData.patientName,
            departmentId: department.id,
            diagnosis: caseData.diagnosis || "",
            symptoms: caseData.symptoms || "",
            treatment: "",
            notes: caseData.notes || "",
            parentName: "",
            parentPhone: caseData.parentPhone || "",
            nationalId: caseData.nationalId || "",
            fileNumber: "",
            caseType: caseData.careType as any,
            artificialRespiration: caseData.artificialRespiration as any,
          });
          successCount++;
        } catch (error: any) {
          const errorMsg = error?.message || "خطأ غير معروف";
          failedCases.push({
            name: caseData.patientName,
            reason: errorMsg,
          });
          console.error(`خطأ في استيراد الحالة ${caseData.patientName}:`, error);
        }
      }

      if (successCount > 0) {
        toast.success(
          `🎉 تم استيراد ${successCount} من ${casesToImport.length} حالة بنجاح!`
        );
      }

      if (failedCases.length > 0) {
        const failureMessage = failedCases
          .map((f) => `• ${f.name}: ${f.reason}`)
          .join("\n");
        toast.error(
          `❌ فشل استيراد ${failedCases.length} حالة:\n${failureMessage}`
        );
      }

      if (successCount > 0) {
        setImportStep("input");
        setPastedData("");
        setParsedCases([]);
        setSelectedDepartmentId(0);
        setTimeout(() => setLocation("/dashboard"), 2000);
      }
    } catch (error) {
      toast.error("❌ حدث خطأ أثناء الاستيراد");
      console.error(error);
    } finally {
      setIsImporting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center gap-4">
          <Button
            onClick={() => setLocation("/dashboard")}
            variant="outline"
            className="flex items-center gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            العودة
          </Button>
          <h1 className="text-4xl font-bold text-gray-900">📤 الإدخال الجماعي</h1>
        </div>

        {/* Instructions */}
        <Card className="mb-8 border-0 shadow-lg bg-blue-50">
          <CardContent className="pt-6">
            <div className="space-y-3">
              <p className="text-gray-700 font-semibold">📋 صيغة البيانات المطلوبة:</p>
              <p className="text-sm text-gray-600 font-mono bg-white p-3 rounded border border-blue-200">
                الاسم, السن, التشخيص, الهاتف, الرقم القومي, نوع الرعاية, التنفس الصناعي, ملاحظات
              </p>
              <p className="text-sm text-gray-600">
                <strong>مثال:</strong> أحمد محمد, 2, الالتهاب الرئوي, 01012345678, 30012345678901, intensive_care_high, no, حالة حرجة
              </p>
              <p className="text-sm text-gray-600">
                <strong>أنواع الرعاية:</strong> intensive_care_high, intensive_care_medium, picu, incubator
              </p>
              <p className="text-sm text-gray-600">
                <strong>أنواع التنفس:</strong> no, high_frequency, vent, cpap, standby
              </p>
              <div className="bg-green-50 border border-green-200 rounded p-3 mt-3">
                <p className="text-sm text-green-800">
                  <strong>💡 نصيحة:</strong> يمكنك استخدام الذكاء الاصطناعي لتحليل البيانات تلقائياً من أي صيغة نصية!
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Input Step */}
        {importStep === "input" && (
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-indigo-600 to-blue-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Upload className="w-6 h-6" />
                لصق البيانات
              </CardTitle>
              <CardDescription className="text-indigo-100">
                انسخ البيانات من Excel أو أي مصدر آخر والصقها هنا
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {/* AI Toggle */}
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      id="useAI"
                      checked={useAI}
                      onChange={(e) => setUseAI(e.target.checked)}
                      className="w-4 h-4"
                    />
                    <label htmlFor="useAI" className="flex items-center gap-2 cursor-pointer">
                      <Zap className="w-4 h-4 text-amber-600" />
                      <span className="font-semibold text-gray-900">استخدام الذكاء الاصطناعي لتحليل البيانات</span>
                    </label>
                  </div>
                  <p className="text-sm text-gray-600 mt-2 mr-7">
                    يقوم الذكاء الاصطناعي بفهم وتحليل البيانات تلقائياً من أي صيغة نصية، حتى لو لم تكن منسقة بشكل صحيح
                  </p>
                </div>

                {/* Department Selection */}
                <div className="space-y-2">
                  <Label htmlFor="department" className="text-gray-700 font-medium">
                    اختر القسم/الغرفة *
                  </Label>
                  <Select
                    value={selectedDepartmentId.toString()}
                    onValueChange={(value) => setSelectedDepartmentId(parseInt(value))}
                  >
                    <SelectTrigger className="border-gray-300">
                      <SelectValue placeholder="اختر القسم أو الغرفة" />
                    </SelectTrigger>
                    <SelectContent>
                      {departments?.map((department: any) => (
                        <SelectItem key={department.id} value={department.id.toString()}>
                          {department.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Data Input */}
                <Textarea
                  placeholder="الصق البيانات هنا..."
                  value={pastedData}
                  onChange={(e) => setPastedData(e.target.value)}
                  rows={10}
                  className="border-gray-300 font-mono text-sm"
                />
                <div className="flex gap-4">
                  <Button
                    onClick={parseData}
                    disabled={!pastedData.trim() || !selectedDepartmentId || isAnalyzing}
                    className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        جاري التحليل...
                      </>
                    ) : (
                      <>
                        {useAI ? <Zap className="w-4 h-4" /> : null}
                        تحليل البيانات
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={() => {
                      setPastedData("");
                      setUseAI(false);
                    }}
                    variant="outline"
                  >
                    مسح
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Edit Step */}
        {importStep === "edit" && (
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl flex items-center gap-2">
                <Edit2 className="w-6 h-6" />
                تعديل البيانات المستخرجة
              </CardTitle>
              <CardDescription className="text-orange-100">
                يمكنك تعديل أي بيانات قبل التأكيد والاستيراد
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {/* Department Info */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-sm text-gray-700">
                    <strong>القسم المختار:</strong> {departments?.find((d: any) => d.id === selectedDepartmentId)?.name || "غير محدد"}
                  </p>
                </div>

                {/* Cases Edit List */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {parsedCases.map((caseData, index) => (
                    <div key={index}>
                      {editingIndex === index && editingData ? (
                        // Edit Mode
                        <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4 space-y-3">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">اسم المريض *</Label>
                              <Input
                                value={editingData.patientName}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, patientName: e.target.value })
                                }
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">السن</Label>
                              <Input
                                value={editingData.age}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, age: e.target.value })
                                }
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">التشخيص</Label>
                              <Input
                                value={editingData.diagnosis}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, diagnosis: e.target.value })
                                }
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">الهاتف</Label>
                              <Input
                                value={editingData.parentPhone}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, parentPhone: e.target.value })
                                }
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">الرقم القومي</Label>
                              <Input
                                value={editingData.nationalId}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, nationalId: e.target.value })
                                }
                                className="text-sm"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">نوع الرعاية</Label>
                              <Select
                                value={editingData.careType}
                                onValueChange={(value) =>
                                  setEditingData({ ...editingData, careType: value })
                                }
                              >
                                <SelectTrigger className="text-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="intensive_care_high">عناية كبيرة</SelectItem>
                                  <SelectItem value="intensive_care_medium">عناية متوسطة</SelectItem>
                                  <SelectItem value="picu">بيكيو</SelectItem>
                                  <SelectItem value="incubator">محضن</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">التنفس الصناعي</Label>
                              <Select
                                value={editingData.artificialRespiration}
                                onValueChange={(value) =>
                                  setEditingData({ ...editingData, artificialRespiration: value })
                                }
                              >
                                <SelectTrigger className="text-sm">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="no">لا</SelectItem>
                                  <SelectItem value="high_frequency">عالي التردد</SelectItem>
                                  <SelectItem value="vent">فينت</SelectItem>
                                  <SelectItem value="cpap">سباب</SelectItem>
                                  <SelectItem value="standby">استاندباي</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                            <div className="md:col-span-2 space-y-1">
                              <Label className="text-xs font-semibold">الأعراض</Label>
                              <Textarea
                                value={editingData.symptoms}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, symptoms: e.target.value })
                                }
                                className="text-sm"
                                rows={2}
                              />
                            </div>
                            <div className="md:col-span-2 space-y-1">
                              <Label className="text-xs font-semibold">ملاحظات</Label>
                              <Textarea
                                value={editingData.notes}
                                onChange={(e) =>
                                  setEditingData({ ...editingData, notes: e.target.value })
                                }
                                className="text-sm"
                                rows={2}
                              />
                            </div>
                          </div>
                          <div className="flex gap-2 pt-2">
                            <Button
                              onClick={saveEditedCase}
                              className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                              size="sm"
                            >
                              <Save className="w-4 h-4" />
                              حفظ
                            </Button>
                            <Button
                              onClick={cancelEditing}
                              variant="outline"
                              size="sm"
                            >
                              <X className="w-4 h-4" />
                              إلغاء
                            </Button>
                          </div>
                        </div>
                      ) : (
                        // View Mode
                        <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200 hover:border-indigo-300 transition">
                          <div className="flex-1">
                            <p className="font-semibold text-gray-900">{caseData.patientName}</p>
                            <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-600">
                              <div>السن: {caseData.age || "غير محدد"}</div>
                              <div>التشخيص: {caseData.diagnosis || "غير محدد"}</div>
                              <div>الرعاية: {caseData.careType}</div>
                              <div>التنفس: {caseData.artificialRespiration}</div>
                              {caseData.symptoms && <div className="col-span-2">الأعراض: {caseData.symptoms}</div>}
                            </div>
                          </div>
                          <Button
                            onClick={() => startEditingCase(index)}
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            تعديل
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4 pt-4 border-t">
                  <Button
                    onClick={() => setImportStep("preview")}
                    className="bg-blue-600 hover:bg-blue-700 text-white flex-1"
                  >
                    التالي - مراجعة والاستيراد
                  </Button>
                  <Button
                    onClick={() => {
                      setImportStep("input");
                      setParsedCases([]);
                    }}
                    variant="outline"
                  >
                    العودة
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Preview Step */}
        {importStep === "preview" && (
          <Card className="border-0 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl flex items-center gap-2">
                <CheckCircle className="w-6 h-6" />
                مراجعة البيانات النهائية
              </CardTitle>
              <CardDescription className="text-purple-100">
                تم تحليل {parsedCases.length} حالة - اختر الحالات المراد استيرادها
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="space-y-4">
                {/* Department Info */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                  <p className="text-sm text-gray-700">
                    <strong>القسم المختار:</strong> {departments?.find((d: any) => d.id === selectedDepartmentId)?.name || "غير محدد"}
                  </p>
                </div>

                {/* Select All Checkbox */}
                <div className="flex items-center gap-3 pb-4 border-b">
                  <input
                    type="checkbox"
                    id="selectAll"
                    checked={selectedCases.length === parsedCases.length}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedCases(parsedCases.map((_, i) => i));
                      } else {
                        setSelectedCases([]);
                      }
                    }}
                    className="w-4 h-4"
                  />
                  <label htmlFor="selectAll" className="font-semibold text-gray-900">
                    اختر الكل ({selectedCases.length}/{parsedCases.length})
                  </label>
                </div>

                {/* Cases List */}
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {parsedCases.map((caseData, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <input
                        type="checkbox"
                        checked={selectedCases.includes(index)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedCases([...selectedCases, index]);
                          } else {
                            setSelectedCases(selectedCases.filter((i) => i !== index));
                          }
                        }}
                        className="w-4 h-4 mt-1"
                      />
                      <div className="flex-1">
                        <p className="font-semibold text-gray-900">{caseData.patientName}</p>
                        <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-600">
                          <div>السن: {caseData.age || "غير محدد"}</div>
                          <div>التشخيص: {caseData.diagnosis || "غير محدد"}</div>
                          <div>الرعاية: {caseData.careType}</div>
                          <div>التنفس: {caseData.artificialRespiration}</div>
                          {caseData.symptoms && <div className="col-span-2">الأعراض: {caseData.symptoms}</div>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-4 pt-4 border-t">
                  <Button
                    onClick={handleImport}
                    disabled={selectedCases.length === 0 || isImporting}
                    className="bg-green-600 hover:bg-green-700 text-white flex-1 flex items-center justify-center gap-2"
                  >
                    {isImporting ? (
                      <>
                        <Loader className="w-4 h-4 animate-spin" />
                        جاري الاستيراد...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        استيراد {selectedCases.length} حالة
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={() => setImportStep("edit")}
                    variant="outline"
                  >
                    العودة للتعديل
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
