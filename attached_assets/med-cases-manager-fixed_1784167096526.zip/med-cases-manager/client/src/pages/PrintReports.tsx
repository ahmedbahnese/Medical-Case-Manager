import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { ArrowRight, Printer, FileText, Download, BarChart3 } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function PrintReports() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: departments } = trpc.departments.list.useQuery();
  const { data: allCases } = trpc.cases.search.useQuery({});

  const [selectedDepartments, setSelectedDepartments] = useState<number[]>([]);
  const [reportType, setReportType] = useState<"summary" | "detailed" | "statistics">("summary");
  const [isPrinting, setIsPrinting] = useState(false);

  const toggleDepartment = (deptId: number) => {
    setSelectedDepartments((prev) =>
      prev.includes(deptId) ? prev.filter((id) => id !== deptId) : [...prev, deptId]
    );
  };

  const selectAll = () => {
    if (departments) {
      if (selectedDepartments.length === departments.length) {
        setSelectedDepartments([]);
      } else {
        setSelectedDepartments(departments.map((d: any) => d.id));
      }
    }
  };

  const getFilteredCases = () => {
    if (!allCases) return [];
    if (selectedDepartments.length === 0) return [];
    return allCases.filter((c: any) => selectedDepartments.includes(c.departmentId));
  };

  const handlePrint = () => {
    if (selectedDepartments.length === 0) {
      toast.error("❌ يرجى اختيار قسم واحد على الأقل");
      return;
    }

    setIsPrinting(true);

    try {
      const filteredCases = getFilteredCases();
      const selectedDeptNames = (departments
        ?.filter((d: any) => selectedDepartments.includes(d.id))
        .map((d: any) => d.name)
        .join(" + ")) || "الأقسام المختارة";

      // Create print window
      const printWindow = window.open("", "", "width=900,height=700");
      if (!printWindow) {
        toast.error("❌ تعذر فتح نافذة الطباعة");
        return;
      }

      const htmlContent = generatePrintHTML(
        filteredCases,
        selectedDeptNames,
        reportType,
        departments
      );

      printWindow.document.write(htmlContent);
      printWindow.document.close();

      // Wait for content to load then print
      printWindow.onload = () => {
        printWindow.print();
        setTimeout(() => {
          printWindow.close();
          setIsPrinting(false);
          toast.success("✅ تم فتح نافذة الطباعة بنجاح");
        }, 500);
      };
    } catch (error) {
      toast.error("❌ حدث خطأ أثناء إعداد التقرير");
      console.error(error);
      setIsPrinting(false);
    }
  };

  const handleDownloadPDF = () => {
    if (selectedDepartments.length === 0) {
      toast.error("❌ يرجى اختيار قسم واحد على الأقل");
      return;
    }

    const filteredCases = getFilteredCases();
    const selectedDeptNames = departments
      ?.filter((d: any) => selectedDepartments.includes(d.id))
      .map((d: any) => d.name)
      .join("_");

    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "اسم المريض,الرقم القومي,رقم الملف,التشخيص,القسم,التاريخ\n";

    filteredCases.forEach((caseData: any) => {
      const row = [
        caseData.patientName,
        caseData.nationalId || "",
        caseData.fileNumber || "",
        caseData.diagnosis || "",
        departments?.find((d: any) => d.id === caseData.departmentId)?.name || "",
        new Date(caseData.createdAt).toLocaleDateString("ar-EG"),
      ];
      csvContent += row.map((cell) => `"${cell}"`).join(",") + "\n";
    });

    // Download CSV
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `تقرير_${selectedDeptNames}_${new Date().toISOString().split("T")[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast.success("✅ تم تحميل التقرير بنجاح");
  };

  const getStatistics = () => {
    const cases = getFilteredCases();
    return {
      total: cases.length,
      withArtificialRespiration: cases.filter((c: any) => c.artificialRespiration !== "no").length,
      criticalCases: cases.filter((c: any) => c.caseType === "intensive_care_high").length,
    };
  };

  const stats = getStatistics();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex items-center gap-4">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="gap-2"
          >
            <ArrowRight className="w-4 h-4" />
            العودة
          </Button>
          <div>
            <h1 className="text-4xl font-bold text-gray-900">📊 طباعة التقارير</h1>
            <p className="text-gray-600 mt-1">اختر الأقسام وطباعة التقارير المجمعة</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Selection */}
          <div className="lg:col-span-2 space-y-6">
            {/* Department Selection Card */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  اختر الأقسام
                </CardTitle>
                <CardDescription className="text-blue-100">
                  اختر قسم واحد أو أكثر لطباعة التقرير المجمع
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  {/* Select All Button */}
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border-2 border-blue-200">
                    <Checkbox
                      id="selectAll"
                      checked={
                        departments && selectedDepartments.length === departments.length
                      }
                      onCheckedChange={selectAll}
                    />
                    <label
                      htmlFor="selectAll"
                      className="cursor-pointer font-semibold text-gray-900 flex-1"
                    >
                      {departments && selectedDepartments.length === departments.length
                        ? "✅ إلغاء تحديد الكل"
                        : "📋 تحديد جميع الأقسام"}
                    </label>
                  </div>

                  {/* Departments List */}
                  <div className="space-y-2 border-t pt-4">
                    {departments?.map((dept: any) => (
                      <div
                        key={dept.id}
                        className={`flex items-center gap-3 p-3 rounded-lg border-2 transition-all cursor-pointer ${
                          selectedDepartments.includes(dept.id)
                            ? "bg-green-50 border-green-300"
                            : "bg-white border-gray-200 hover:border-gray-300"
                        }`}
                        onClick={() => toggleDepartment(dept.id)}
                      >
                        <Checkbox
                          id={`dept-${dept.id}`}
                          checked={selectedDepartments.includes(dept.id)}
                          onCheckedChange={() => toggleDepartment(dept.id)}
                        />
                        <label
                          htmlFor={`dept-${dept.id}`}
                          className="cursor-pointer flex-1"
                        >
                          <div className="font-semibold text-gray-900">{dept.name}</div>
                          <div className="text-sm text-gray-600">
                            السعة: {dept.capacity} سرير
                          </div>
                        </label>
                        {selectedDepartments.includes(dept.id) && (
                          <div className="text-green-600 font-bold">✓</div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Report Type Selection */}
            <Card className="border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-t-lg">
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  نوع التقرير
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg hover:border-purple-300 cursor-pointer"
                    onClick={() => setReportType("summary")}>
                    <input
                      type="radio"
                      id="summary"
                      name="reportType"
                      value="summary"
                      checked={reportType === "summary"}
                      onChange={() => setReportType("summary")}
                      className="w-4 h-4"
                    />
                    <label htmlFor="summary" className="cursor-pointer flex-1">
                      <div className="font-semibold text-gray-900">📄 تقرير مختصر</div>
                      <div className="text-sm text-gray-600">قائمة بأسماء المرضى والتشخيص</div>
                    </label>
                  </div>

                  <div className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg hover:border-purple-300 cursor-pointer"
                    onClick={() => setReportType("detailed")}>
                    <input
                      type="radio"
                      id="detailed"
                      name="reportType"
                      value="detailed"
                      checked={reportType === "detailed"}
                      onChange={() => setReportType("detailed")}
                      className="w-4 h-4"
                    />
                    <label htmlFor="detailed" className="cursor-pointer flex-1">
                      <div className="font-semibold text-gray-900">📋 تقرير تفصيلي</div>
                      <div className="text-sm text-gray-600">جميع البيانات والملاحظات</div>
                    </label>
                  </div>

                  <div className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg hover:border-purple-300 cursor-pointer"
                    onClick={() => setReportType("statistics")}>
                    <input
                      type="radio"
                      id="statistics"
                      name="reportType"
                      value="statistics"
                      checked={reportType === "statistics"}
                      onChange={() => setReportType("statistics")}
                      className="w-4 h-4"
                    />
                    <label htmlFor="statistics" className="cursor-pointer flex-1">
                      <div className="font-semibold text-gray-900">📊 إحصائيات</div>
                      <div className="text-sm text-gray-600">إجمالي الحالات والإحصائيات</div>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Preview & Actions */}
          <div className="space-y-6">
            {/* Statistics Card */}
            <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-emerald-50">
              <CardHeader>
                <CardTitle className="text-lg">📊 الإحصائيات</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-green-600">{stats.total}</div>
                  <div className="text-sm text-gray-600">إجمالي الحالات</div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">{stats.withArtificialRespiration}</div>
                    <div className="text-xs text-gray-600">تنفس صناعي</div>
                  </div>
                  <div className="bg-white p-3 rounded-lg text-center">
                    <div className="text-2xl font-bold text-red-600">{stats.criticalCases}</div>
                    <div className="text-xs text-gray-600">حالات حرجة</div>
                  </div>
                </div>

                {selectedDepartments.length > 0 && (
                  <div className="bg-white p-3 rounded-lg">
                    <div className="text-xs font-semibold text-gray-700 mb-2">الأقسام المختارة:</div>
                    <div className="space-y-1">
                      {departments
                        ?.filter((d: any) => selectedDepartments.includes(d.id))
                        .map((d: any) => (
                          <div key={d.id} className="text-xs text-gray-600">
                            ✓ {d.name}
                          </div>
                        ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={handlePrint}
                disabled={isPrinting || selectedDepartments.length === 0}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white text-lg py-6 flex items-center justify-center gap-2"
              >
                {isPrinting ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                    جاري الإعداد...
                  </>
                ) : (
                  <>
                    <Printer className="w-5 h-5" />
                    طباعة التقرير
                  </>
                )}
              </Button>

              <Button
                onClick={handleDownloadPDF}
                disabled={selectedDepartments.length === 0}
                variant="outline"
                className="w-full text-lg py-6 flex items-center justify-center gap-2"
              >
                <Download className="w-5 h-5" />
                تحميل كـ CSV
              </Button>

              <Button
                onClick={() => setLocation("/dashboard")}
                variant="ghost"
                className="w-full text-lg py-6"
              >
                إلغاء
              </Button>
            </div>

            {/* Info Box */}
            <Card className="border-0 shadow-lg bg-yellow-50">
              <CardContent className="pt-6">
                <div className="text-sm text-gray-700 space-y-2">
                  <p className="font-semibold">💡 نصائح:</p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li>اختر قسم واحد أو أكثر</li>
                    <li>اختر نوع التقرير المناسب</li>
                    <li>اضغط طباعة أو تحميل</li>
                    <li>استخدم Ctrl+P للطباعة</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Print Styles */}
      <style>{`
        @media print {
          body {
            background: white;
            margin: 0;
            padding: 20px;
          }
          .no-print {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
}

function generatePrintHTML(
  cases: any[],
  deptNames: string,
  reportType: string,
  departments: any
): string {
  const now = new Date().toLocaleString("ar-EG");
  const pageTitle = `تقرير الحالات الطبية - ${deptNames}`;

  let tableHTML = "";

  if (reportType === "summary") {
    tableHTML = `
      <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
          <tr style="background-color: #3b82f6; color: white;">
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">اسم المريض</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">الرقم القومي</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">التشخيص</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">القسم</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">التاريخ</th>
          </tr>
        </thead>
        <tbody>
          ${cases
            .map(
              (c) => `
            <tr>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.patientName}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.nationalId || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.diagnosis || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${
                departments?.find((d: any) => d.id === c.departmentId)?.name || "-"
              }</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${new Date(
                c.createdAt
              ).toLocaleDateString("ar-EG")}</td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  } else if (reportType === "detailed") {
    tableHTML = `
      <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
        <thead>
          <tr style="background-color: #3b82f6; color: white;">
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">اسم المريض</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">الرقم القومي</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">التشخيص</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">الأعراض</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">التنفس الصناعي</th>
            <th style="border: 1px solid #ddd; padding: 10px; text-align: right;">القسم</th>
          </tr>
        </thead>
        <tbody>
          ${cases
            .map(
              (c) => `
            <tr>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.patientName}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.nationalId || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.diagnosis || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.symptoms || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${c.artificialRespiration || "-"}</td>
              <td style="border: 1px solid #ddd; padding: 10px;">${
                departments?.find((d: any) => d.id === c.departmentId)?.name || "-"
              }</td>
            </tr>
          `
            )
            .join("")}
        </tbody>
      </table>
    `;
  } else {
    const stats = {
      total: cases.length,
      withArtificialRespiration: cases.filter((c) => c.artificialRespiration !== "no").length,
      criticalCases: cases.filter((c) => c.caseType === "intensive_care_high").length,
    };

    tableHTML = `
      <div style="margin-top: 20px;">
        <h3 style="text-align: center; font-size: 18px; margin-bottom: 20px;">الإحصائيات</h3>
        <table style="width: 100%; border-collapse: collapse;">
          <tr>
            <td style="border: 1px solid #ddd; padding: 15px; text-align: center;">
              <div style="font-size: 24px; font-weight: bold; color: #3b82f6;">${stats.total}</div>
              <div style="font-size: 14px; color: #666;">إجمالي الحالات</div>
            </td>
            <td style="border: 1px solid #ddd; padding: 15px; text-align: center;">
              <div style="font-size: 24px; font-weight: bold; color: #10b981;">${stats.withArtificialRespiration}</div>
              <div style="font-size: 14px; color: #666;">حالات التنفس الصناعي</div>
            </td>
            <td style="border: 1px solid #ddd; padding: 15px; text-align: center;">
              <div style="font-size: 24px; font-weight: bold; color: #ef4444;">${stats.criticalCases}</div>
              <div style="font-size: 14px; color: #666;">الحالات الحرجة</div>
            </td>
          </tr>
        </table>
      </div>
    `;
  }

  return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${pageTitle}</title>
      <style>
        body {
          font-family: 'Arial', sans-serif;
          direction: rtl;
          margin: 0;
          padding: 20px;
          background: white;
        }
        .header {
          text-align: center;
          margin-bottom: 30px;
          border-bottom: 3px solid #3b82f6;
          padding-bottom: 15px;
        }
        .header h1 {
          margin: 0;
          color: #1f2937;
          font-size: 24px;
        }
        .header p {
          margin: 5px 0;
          color: #666;
          font-size: 14px;
        }
        table {
          width: 100%;
          border-collapse: collapse;
        }
        th, td {
          padding: 12px;
          text-align: right;
          border: 1px solid #ddd;
        }
        th {
          background-color: #3b82f6;
          color: white;
          font-weight: bold;
        }
        tr:nth-child(even) {
          background-color: #f9fafb;
        }
        .footer {
          margin-top: 30px;
          text-align: center;
          font-size: 12px;
          color: #999;
          border-top: 1px solid #ddd;
          padding-top: 15px;
        }
        @media print {
          body {
            margin: 0;
            padding: 10px;
          }
        }
      </style>
    </head>
    <body>
      <div class="header">
        <h1>${pageTitle}</h1>
        <p>نظام إدارة الحالات الطبية - BSCH</p>
        <p>تاريخ الطباعة: ${now}</p>
      </div>
      ${tableHTML}
      <div class="footer">
        <p>© 2026 نظام إدارة الحالات الطبية - مستشفى الأطفال المتخصص بالبحيرة</p>
      </div>
    </body>
    </html>
  `;
}
